﻿using System;

namespace Reto
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Edificio");
            string[] nom = new string[5];
            pruebaVector pv = new pruebaVector();
            pv.Cargar();
            pv.Imprimir();
        }
        class pruebaVector
        {
            private int[] personas;
            private int[] nas;
            private int[] noss;
            private int[] total;
            string[] nom = new string[5];

            public void Cargar()
            {
                personas = new int[5];
                noss = new int[5];
                nas = new int[5];
                total = new int[5];
               

             

                for (int f = 0; f < 5; f++)
                {
                    Console.WriteLine("Ingrese el nivel ");
                    string linea;

                    linea = Console.ReadLine();
                    personas[f] = int.Parse(linea);


                    Console.WriteLine("Ingresa el numero adultos : ");

                    string niños;

                    niños = Console.ReadLine();
                    noss[f] = int.Parse(niños);


                    Console.WriteLine("Ingresa el numero niños : ");
                    string niñas;


                    niñas = Console.ReadLine();

                    nas[f] = int.Parse(niñas);


                    Console.WriteLine("Ingrese el total de personas:  ");
                    string finalt;

                    finalt = Console.ReadLine();

                    total[f] = int.Parse(finalt);

              
                     Console.WriteLine("Nombre de la persona encargada: ");
                    nom[f] = Console.ReadLine();

                }
            }
            public void Imprimir()
            {
                for (int f = 0; f < 5; f++)
                {
                    Console.WriteLine("");
                    Console.WriteLine("en el nivel: ");
                    Console.WriteLine(personas[f]);
                    Console.WriteLine("La cantidad de niños es de:  ");
                    Console.WriteLine(nas[f]);
                    Console.WriteLine("El total de personas es de: ");
                    Console.WriteLine(total[f]);
                    Console.WriteLine("El encargado es : ");
                    Console.WriteLine(nom[f]);


                }

  
                if (personas[0] > total[1] && total[0] > total[2] && total[0] > total[3] && total[0] > total[4])
                {
                    Console.WriteLine("responsable del nivel  con más personas: " );

                }

                if (total[1] > total[0] && total[1] > total[2] && total[1] > total[3] && total[1] > total[4])
                {
                    Console.WriteLine("responsable del nivel  con más personas: " );
                }

                if (total[2] > total[0] && total[2] > total[1] && total[2] > total[3] && total[2] > total[4])
                {
                    Console.WriteLine("responsable del nivel  con más personas:"  );
                }

                if (total[3] > total[0] && total[3] > total[1] && total[3] > total[2] && total[3] > total[4])
                {
                    Console.WriteLine("responsable del nivel  con más personas: " );
                }

                if (total[4] > total[0] && total[4] > total[1] && total[4] > total[2] && total[4] > total[3])
                {
                    Console.WriteLine("responsable del nivel  con más personas es: " );
                }

                for (int f = 0; f < 1; f++)
                {
                    
                        Console.WriteLine(nom[f]);

                    
                }


                Console.ReadKey();
            }
        }
    }
}