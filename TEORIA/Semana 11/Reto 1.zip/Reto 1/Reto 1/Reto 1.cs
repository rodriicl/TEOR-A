﻿using Microsoft.VisualBasic;
using System;

namespace RETO1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("HABITANTES DE UN EDIFICO");
            pruebaVector pv = new pruebaVector();
            pv.Cargar();
            pv.Imprimir();
        }

        class pruebaVector
        {
            private int[] Nivel1Per;
            private int[] Nivel2Per;
            private int[] Nivel3Per;
            private int[] Nivel4Per;
            private int[] Nivel5Per;
            public int Personas1;
            public int Personas2;
            public int Personas3;
            public int Personas4;
            public int Personas5;

            public void Cargar()
            {
                Nivel1Per = new int[1];
                for (int f = 0; f < 1; f++)
                {
                    Console.WriteLine("Ingrese el número de personas que viven en el primer nivel)");
                    string linea;
                    linea = Console.ReadLine();
                    Nivel1Per[f] = int.Parse(linea);
                    Personas1 = Nivel1Per[f];
                }

                Nivel2Per = new int[01];
                for (int f = 0; f < 1; f++)
                {
                    Console.WriteLine("Ingrese el número de personas que viven en el segundo nivel)");
                    string linea;
                    linea = Console.ReadLine();
                    Nivel2Per[f] = int.Parse(linea);
                    Personas2 = Nivel2Per[f];
                }

                Nivel3Per = new int[1];
                for (int f = 0; f < 1; f++)
                {
                    Console.WriteLine("Ingrese el número de personas que viven en el tercer nivel)");
                    string linea;
                    linea = Console.ReadLine();
                    Nivel3Per[f] = int.Parse(linea);
                    Personas3 = Nivel3Per[f];
                }

                Nivel4Per = new int[1];
                for (int f = 0; f < 1; f++)
                {
                    Console.WriteLine("Ingrese el número de personas que viven en el cuarto nivel)");
                    string linea;
                    linea = Console.ReadLine();
                    Nivel4Per[f] = int.Parse(linea);
                    Personas4 = Nivel4Per[f];
                }

                Nivel5Per = new int[1];
                for (int f = 0; f < 1; f++)
                {
                    Console.WriteLine("Ingrese el número de personas que viven en el quinto nivel");
                    string linea;
                    linea = Console.ReadLine();
                    Nivel5Per[f] = int.Parse(linea);
                    Personas5 = Nivel5Per[f];
                }

            }
            public void Imprimir()
            {
                for (int f = 0; f < 1; f++)
                {
                    Console.WriteLine("");
                    Console.WriteLine("En el primer nivel viven ");
                    Console.WriteLine(Nivel1Per[f]);
                }

                for (int f = 0; f < 1; f++)
                {
                    Console.WriteLine("");
                    Console.WriteLine("En el segundo nivel viven ");
                    Console.WriteLine(Nivel2Per[f]);
                }

                for (int f = 0; f < 1; f++)
                {
                    Console.WriteLine("");
                    Console.WriteLine("En el tercer nivel viven ");
                    Console.WriteLine(Nivel3Per[f]);
                }

                for (int f = 0; f < 1; f++)
                {
                    Console.WriteLine("");
                    Console.WriteLine("En el cuarto nivel viven ");
                    Console.WriteLine(Nivel4Per[f]);
                }

                for (int f = 0; f < 1; f++)
                {
                    Console.WriteLine("");
                    Console.WriteLine("En el quinto nivel viven ");
                    Console.WriteLine(Nivel5Per[f]);
                }

                if (Personas1 < Personas2 && Personas1 < Personas3 && Personas1 < Personas4 && Personas1 < Personas5);
                {
                    Console.WriteLine("El nivel con menor personas es el primero nivel");
                }

                if (Personas2 < Personas1 && Personas2 < Personas3 && Personas2 < Personas4 && Personas2 < Personas5) ;
                {
                    Console.WriteLine("El nivel con menor personas es el segundo nivel");
                }
                if (Personas3 < Personas1 && Personas3 < Personas2 && Personas3 < Personas4 && Personas3 < Personas5) ;
                {
                    Console.WriteLine("El nivel con menor personas es el tercero nivel");
                }
                if (Personas4 < Personas1 && Personas4 < Personas2 && Personas4 < Personas3 && Personas4 < Personas5) ;
                {
                    Console.WriteLine("El nivel con menor personas es el cuarto nivel");
                }
                if (Personas5 < Personas1 && Personas5 < Personas2 && Personas5 < Personas3 && Personas5 < Personas4);
                {
                    Console.WriteLine("El nivel con menor personas es el quinto nivel");
                }
                


            }

        }
    }
}