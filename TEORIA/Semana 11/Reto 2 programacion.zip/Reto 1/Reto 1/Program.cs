﻿using System;

namespace Reto
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Edificio");
            pruebaVector pv = new pruebaVector();
            pv.Cargar();
            pv.Imprimir();
        }
        class pruebaVector
        {
            private int[] personas;
            private int[] nas;
            private int[] noss;
            int mayor = 0;


            public void Cargar()
            {
                personas = new int[5];
                noss = new int[5];
                nas = new int[5];
                for (int f = 0; f < 5; f++)
                {

                    Console.WriteLine("Ingrese el nivel ");
                    string linea;

                    linea = Console.ReadLine();
                    personas[f] = int.Parse(linea);
                   

                    Console.WriteLine("Ingresa el numero niños : ");
                   
                    string niños;

                    niños = Console.ReadLine();
                    noss[f] = int.Parse(niños);


                    Console.WriteLine("Ingresa el numero niñas : ");
                    string niñas;


                    niñas = Console.ReadLine();

                    nas[f] = int.Parse(niñas);
                }
            }
            public void Imprimir()
            {
                for (int f = 0; f < 5; f++)
                {
                    Console.WriteLine("");
                    Console.WriteLine("en el nivel " );
                    Console.WriteLine(personas[f]);
                   Console.WriteLine("La cantidad de niñas es de  ");
                    Console.WriteLine(nas[f]);
                    Console.WriteLine("La cantidad de niños es de  ");
                    Console.WriteLine(noss[f]);



                }

                if (personas[0] > noss[1] && noss[0] > noss[2] && noss[0] > noss[3] && noss[0] > noss[4])
                {
                    Console.WriteLine("El nivel con mas niños es el primero. ");
                }

                if (noss[1] > noss[0] && noss[1] > noss[2] && noss[1] > noss[3] && noss[1] > noss[4])
                {
                    Console.WriteLine("El nivel con mas niños es el segundo.");
                }

                if (noss[2] > noss[0] && noss[2] > noss[1] && noss[2] > noss[3] && noss[2] > noss[4])
                {
                    Console.WriteLine("El nivel con mas niños es el tercero.");
                }

                if (noss[3] > noss[0] && noss[3] > noss[1] && noss[3] > noss[2] && noss[3] > noss[4])
                {
                    Console.WriteLine("El nivel con mas niños es el cuarto");
                }

                if (noss[4] > noss[0] && noss[4] > noss[1] && noss[4] > noss[2] && noss[4] > noss[3])
                {
                    Console.WriteLine("El nivel con mas niños es el quinto.");
                }



                Console.ReadKey();
            }
        }
    }
}